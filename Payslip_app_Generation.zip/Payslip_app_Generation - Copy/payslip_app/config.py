import os

BASE_DIR = os.path.abspath(os.path.dirname(__file__))


class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY", "change-me-in-prod")
    SQLALCHEMY_DATABASE_URI = "sqlite:///" + os.path.join(BASE_DIR, "instance", "payslip.db")
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    
    HR_USERNAME = "admin"
    HR_PASSWORD = "admin123"


    COMPANY_NAME = "ELVERVE"
    COMPANY_ADDRESS = "1st Floor, Aztech Coworking Space,\nBrookfields Mall, Coimbatore - 641001"

    EXPORT_DIR = os.path.join(BASE_DIR, "exports")


    
    SMTP_HOST = os.environ.get("SMTP_HOST", "smtp.office365.com")
    SMTP_PORT = int(os.environ.get("SMTP_PORT", "587"))
    SMTP_USER = os.environ.get("SMTP_USER", "")            # HR Outlook email address
    SMTP_PASSWORD = os.environ.get("SMTP_PASSWORD", "")    # app password
    SMTP_FROM = os.environ.get("SMTP_FROM", os.environ.get("SMTP_USER", ""))
    SMTP_USE_TLS = os.environ.get("SMTP_USE_TLS", "1") == "1"
