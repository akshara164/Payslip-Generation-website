"""Generate a payslip PDF that mirrors the uploaded reference layout."""
import os
from io import BytesIO
from datetime import date
from calendar import month_name

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, KeepTogether, Image
)

from .num_words import num_to_indian_words

LOGO_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "static", "elverve_logo.png")


def _watermark(canvas, doc):
    """Draw a large diagonal ELVERVE watermark behind the content."""
    canvas.saveState()
    canvas.setFont("Helvetica-Bold", 90)
    canvas.setFillColorRGB(0.85, 0.87, 0.92, alpha=0.18)
    w, h = A4
    canvas.translate(w / 2, h / 2)
    canvas.rotate(30)
    canvas.drawCentredString(0, 0, "ELVERVE")
    canvas.restoreState()


INR = "Rs."


def _money(v):
    return f"{INR}{v:,.2f}"


def build_payslip_pdf(payslip, employee, run, company_name, company_address, ytd_map=None):
    """ytd_map: dict of field_name -> 'Master' (un-prorated salary-version) values."""
    master_map = ytd_map or {}
    buf = BytesIO()
    doc = SimpleDocTemplate(
        buf, pagesize=A4,
        leftMargin=15 * mm, rightMargin=15 * mm,
        topMargin=15 * mm, bottomMargin=15 * mm,
        title=f"Payslip {employee.name} {month_name[run.month]} {run.year}",
    )
    styles = getSampleStyleSheet()
    h_company = ParagraphStyle("hc", parent=styles["Title"], fontSize=18,
                               textColor=colors.HexColor("#1a1a1a"), alignment=0, spaceAfter=2)
    addr = ParagraphStyle("addr", parent=styles["Normal"], fontSize=9,
                          textColor=colors.HexColor("#555"), spaceAfter=2)
    payslip_label = ParagraphStyle("pl", parent=styles["Normal"], fontSize=11,
                                   textColor=colors.HexColor("#444"), alignment=2)
    period = ParagraphStyle("pp", parent=styles["Normal"], fontSize=10,
                            textColor=colors.HexColor("#666"), alignment=2)
    section = ParagraphStyle("sec", parent=styles["Normal"], fontSize=11,
                             textColor=colors.HexColor("#1a1a1a"),
                             fontName="Helvetica-Bold", spaceBefore=8, spaceAfter=4)
    small = ParagraphStyle("sm", parent=styles["Normal"], fontSize=9)
    foot = ParagraphStyle("ft", parent=styles["Normal"], fontSize=8,
                          textColor=colors.HexColor("#888"), alignment=1)

    story = []

    
    address_lines = [ln for ln in (company_address or "").split("\n") if ln.strip()]
    if not address_lines:
        address_lines = [""]
    line1 = address_lines[0]
    line2 = "<br/>".join(address_lines[1:]) if len(address_lines) > 1 else ""

    try:
        logo = Image(LOGO_PATH, width=42 * mm, height=14 * mm, kind="proportional")
        logo_cell = [logo]
    except Exception:
        logo_cell = [Paragraph(company_name, h_company)]

    header_data = [
        [logo_cell, ""],
        [Paragraph(line1, addr), Paragraph("<b>PAYSLIP</b>", payslip_label)],
        [Paragraph(line2, addr), Paragraph(f"For the month of {month_name[run.month]} {run.year}", period)],
    ]
    header = Table(header_data, colWidths=[110 * mm, 65 * mm])
    header.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LINEBELOW", (0, -1), (-1, -1), 0.75, colors.HexColor("#cccccc")),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]))
    story.append(header)
    story.append(Spacer(1, 10))

    
    story.append(Paragraph("EMPLOYEE PAY SUMMARY", section))

    info_left = [
        ["Employee Name", employee.name],
        ["Employee ID", employee.employee_id],
        ["Designation", employee.designation],
        ["Department", employee.department],
        ["Date of Joining", employee.date_of_joining.strftime("%d/%m/%Y")],
        ["Work Location", employee.work_location or "-"],
        ["Bank Account No.", employee.bank_account or "-"],
        ["UAN Number", getattr(employee, "uan_number", None) or "-"],
    ]

    left_tbl = Table(info_left, colWidths=[42 * mm, 60 * mm])
    left_tbl.setStyle(TableStyle([
        ("FONT", (0, 0), (0, -1), "Helvetica", 9),
        ("FONT", (1, 0), (1, -1), "Helvetica-Bold", 9),
        ("TEXTCOLOR", (0, 0), (0, -1), colors.HexColor("#666")),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
        ("TOPPADDING", (0, 0), (-1, -1), 3),
    ]))

    net_box_inner = Table([
        [Paragraph("<b>Employee Net Pay</b>", small)],
        [Paragraph(f"<font size=18 color='#1a8754'><b>{_money(payslip.net)}</b></font>", small)],
        [Paragraph(f"Paid Days : {payslip.days_worked:g} &nbsp;|&nbsp; LOP Days : {payslip.lop_days:g}", small)],
    ], colWidths=[70 * mm])
    net_box_inner.setStyle(TableStyle([
        ("BOX", (0, 0), (-1, -1), 0.75, colors.HexColor("#1a8754")),
        ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#eaf6ee")),
        ("LEFTPADDING", (0, 0), (-1, -1), 10),
        ("RIGHTPADDING", (0, 0), (-1, -1), 10),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ("ALIGN", (0, 0), (-1, -1), "LEFT"),
    ]))

    summary = Table([[left_tbl, net_box_inner]], colWidths=[105 * mm, 75 * mm])
    summary.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ]))
    story.append(summary)
    story.append(Spacer(1, 10))

    
    earnings_rows = [
        ("Basic", payslip.basic),
        ("House Rent Allowance", payslip.hra),
        ("Education Allowance", payslip.education_allowance),
        ("Leave and Travel Allowance", payslip.lta),
        ("Personal Allowance", payslip.personal_allowance),
    ]
    field_keys = ["basic", "hra", "education_allowance", "lta", "personal_allowance"]

    earn_table = [["EARNINGS", "MASTER", "ACTUAL"]]
    for (label, amt), key in zip(earnings_rows, field_keys):
        earn_table.append([label, _money(master_map.get(key, amt)), _money(amt)])
    earn_table.append(["Gross Earnings", "", _money(payslip.gross)])

    et = Table(earn_table, colWidths=[80 * mm, 50 * mm, 50 * mm])
    et.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#f3f4f6")),
        ("FONT", (0, 0), (-1, 0), "Helvetica-Bold", 9),
        ("FONT", (0, 1), (-1, -2), "Helvetica", 9),
        ("FONT", (0, -1), (-1, -1), "Helvetica-Bold", 9),
        ("ALIGN", (1, 0), (-1, -1), "RIGHT"),
        ("LINEBELOW", (0, 0), (-1, 0), 0.5, colors.HexColor("#cccccc")),
        ("LINEABOVE", (0, -1), (-1, -1), 0.5, colors.HexColor("#cccccc")),
        ("BACKGROUND", (0, -1), (-1, -1), colors.HexColor("#fafafa")),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
    ]))
    story.append(et)
    story.append(Spacer(1, 8))

    
    ded_rows = [["DEDUCTIONS", "MASTER", "ACTUAL"]]
    std_deds = [
        ("Employee Contribution to PF", "employee_pf", payslip.employee_pf),
        ("Employer Contribution to PF", "employer_pf", payslip.employer_pf),
        ("Group Medical Insurance", "medical_insurance", payslip.medical_insurance),
    ]
    for label, key, amt in std_deds:
        ded_rows.append([label, _money(master_map.get(key, amt)), _money(amt)])
    for d in payslip.extra_deductions:
        ded_rows.append([d.name, _money(d.amount), _money(d.amount)])
    ded_rows.append(["Total Deductions", "", _money(payslip.total_deductions)])

    dt = Table(ded_rows, colWidths=[80 * mm, 50 * mm, 50 * mm])
    dt.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#f3f4f6")),
        ("FONT", (0, 0), (-1, 0), "Helvetica-Bold", 9),
        ("FONT", (0, 1), (-1, -2), "Helvetica", 9),
        ("FONT", (0, -1), (-1, -1), "Helvetica-Bold", 9),
        ("ALIGN", (1, 0), (-1, -1), "RIGHT"),
        ("LINEBELOW", (0, 0), (-1, 0), 0.5, colors.HexColor("#cccccc")),
        ("LINEABOVE", (0, -1), (-1, -1), 0.5, colors.HexColor("#cccccc")),
        ("BACKGROUND", (0, -1), (-1, -1), colors.HexColor("#fafafa")),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
    ]))
    story.append(dt)
    story.append(Spacer(1, 12))

    
    net_summary = Table([
        [Paragraph("<b>NET PAY (Gross Earnings - Total Deductions)</b>", small),
         Paragraph(f"<b>{_money(payslip.net)}</b>", ParagraphStyle('r', parent=small, alignment=2))],
        [Paragraph("<b>Total Net Payable</b>", small),
         Paragraph(f"<b>{_money(payslip.net)}</b>", ParagraphStyle('r', parent=small, alignment=2))],
    ], colWidths=[130 * mm, 50 * mm])
    net_summary.setStyle(TableStyle([
        ("BOX", (0, 0), (-1, -1), 0.5, colors.HexColor("#cccccc")),
        ("LINEBELOW", (0, 0), (-1, 0), 0.5, colors.HexColor("#cccccc")),
        ("BACKGROUND", (0, 1), (-1, 1), colors.HexColor("#eaf6ee")),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
    ]))
    story.append(net_summary)
    story.append(Spacer(1, 4))
    story.append(Paragraph(f"<i>({num_to_indian_words(payslip.net)})</i>", small))
    story.append(Spacer(1, 16))
    story.append(Paragraph("-- This is a system generated payslip, hence the signature is not required. --", foot))

    doc.build(story)
    buf.seek(0)
    return buf
