"""Generate payslip as a Word (.docx) document mirroring the PDF layout."""
import os
from io import BytesIO
from datetime import date
from calendar import month_name

from docx import Document
from docx.shared import Pt, Cm, RGBColor, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_ALIGN_VERTICAL
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

from .num_words import num_to_indian_words

LOGO_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "static", "elverve_logo.png")
INR = "Rs."


def _money(v):
    return f"{INR}{v:,.2f}"


def _shade(cell, hex_color):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), hex_color)
    tcPr.append(shd)


def _set_cell_border(cell, color="CCCCCC", sz="6"):
    tcPr = cell._tc.get_or_add_tcPr()
    tcBorders = OxmlElement("w:tcBorders")
    for edge in ("top", "left", "bottom", "right"):
        b = OxmlElement(f"w:{edge}")
        b.set(qn("w:val"), "single")
        b.set(qn("w:sz"), sz)
        b.set(qn("w:color"), color)
        tcBorders.append(b)
    tcPr.append(tcBorders)


def _add_watermark_header(section):
    """Add an ELVERVE diagonal watermark via header VML shape."""
    header = section.header
    p = header.paragraphs[0]
    r = p.add_run()
    fldChar = OxmlElement("w:pict")
    vml = (
        '<v:shape xmlns:v="urn:schemas-microsoft-com:vml" '
        'id="WM" type="#_x0000_t136" '
        'style="position:absolute;margin-left:0;margin-top:0;width:500pt;height:120pt;'
        'rotation:-30;z-index:-251658240;mso-position-horizontal:center;'
        'mso-position-horizontal-relative:margin;mso-position-vertical:center;'
        'mso-position-vertical-relative:margin" '
        'fillcolor="#D9D9D9" stroked="f">'
        '<v:fill opacity=".25"/>'
        '<v:textpath style="font-family:&quot;Arial&quot;;font-size:1pt;font-weight:bold" '
        'string="ELVERVE"/>'
        '</v:shape>'
    )
    import re
    from lxml import etree
    pict = etree.fromstring(f'<w:pict xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">{vml}</w:pict>')
    r._r.append(pict)


def _kv_table(doc, rows, label_w=Cm(4.5), val_w=Cm(6.5)):
    t = doc.add_table(rows=len(rows), cols=2)
    t.autofit = False
    for i, (k, v) in enumerate(rows):
        c1 = t.rows[i].cells[0]
        c2 = t.rows[i].cells[1]
        c1.width = label_w
        c2.width = val_w
        p1 = c1.paragraphs[0]
        r1 = p1.add_run(k)
        r1.font.size = Pt(9)
        r1.font.color.rgb = RGBColor(0x66, 0x66, 0x66)
        p2 = c2.paragraphs[0]
        r2 = p2.add_run(str(v))
        r2.font.size = Pt(9)
        r2.bold = True
    return t


def build_payslip_docx(payslip, employee, run, company_name, company_address, ytd_map=None):
    master_map = ytd_map or {}
    doc = Document()

    # Page setup
    for section in doc.sections:
        section.top_margin = Cm(1.5)
        section.bottom_margin = Cm(1.5)
        section.left_margin = Cm(1.5)
        section.right_margin = Cm(1.5)
        try:
            _add_watermark_header(section)
        except Exception:
            pass

    style = doc.styles["Normal"]
    style.font.name = "Arial"
    style.font.size = Pt(10)

    
    header_tbl = doc.add_table(rows=1, cols=2)
    header_tbl.autofit = False
    left = header_tbl.rows[0].cells[0]
    right = header_tbl.rows[0].cells[1]
    left.width = Cm(11)
    right.width = Cm(7)

    lp = left.paragraphs[0]
    if os.path.exists(LOGO_PATH):
        try:
            lp.add_run().add_picture(LOGO_PATH, width=Cm(4.2))
        except Exception:
            lp.add_run(company_name).bold = True
    else:
        lp.add_run(company_name).bold = True
    addr_p = left.add_paragraph()
    for i, line in enumerate((company_address or "").split("\n")):
        if i > 0:
            addr_p.add_run().add_break()
        ar = addr_p.add_run(line)
        ar.font.size = Pt(9)
        ar.font.color.rgb = RGBColor(0x55, 0x55, 0x55)

    rp = right.paragraphs[0]
    rp.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    rr = rp.add_run("PAYSLIP")
    rr.bold = True
    rr.font.size = Pt(14)
    rp2 = right.add_paragraph()
    rp2.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    rr2 = rp2.add_run(f"For the month of {month_name[run.month]} {run.year}")
    rr2.font.size = Pt(10)
    rr2.font.color.rgb = RGBColor(0x66, 0x66, 0x66)

    doc.add_paragraph()

    
    sec = doc.add_paragraph()
    sr = sec.add_run("EMPLOYEE PAY SUMMARY")
    sr.bold = True
    sr.font.size = Pt(11)

    summary_tbl = doc.add_table(rows=1, cols=2)
    summary_tbl.autofit = False
    s_left = summary_tbl.rows[0].cells[0]
    s_right = summary_tbl.rows[0].cells[1]
    s_left.width = Cm(11)
    s_right.width = Cm(7)

    info_rows = [
        ("Employee Name", employee.name),
        ("Employee ID", employee.employee_id),
        ("Designation", employee.designation),
        ("Department", employee.department),
        ("Date of Joining", employee.date_of_joining.strftime("%d/%m/%Y")),
        ("Work Location", employee.work_location or "-"),
        ("Bank Account No.", employee.bank_account or "-"),
        ("UAN Number", getattr(employee, "uan_number", None) or "-"),
    ]
    inner_kv = s_left.add_table(rows=len(info_rows), cols=2)
    for i, (k, v) in enumerate(info_rows):
        c1 = inner_kv.rows[i].cells[0]
        c2 = inner_kv.rows[i].cells[1]
        c1.width = Cm(4.5); c2.width = Cm(6)
        r1 = c1.paragraphs[0].add_run(k)
        r1.font.size = Pt(9); r1.font.color.rgb = RGBColor(0x66, 0x66, 0x66)
        r2 = c2.paragraphs[0].add_run(str(v))
        r2.font.size = Pt(9); r2.bold = True
    
    s_left.paragraphs[0]._element.getparent().remove(s_left.paragraphs[0]._element)

    
    s_right.paragraphs[0]._element.getparent().remove(s_right.paragraphs[0]._element)
    np_tbl = s_right.add_table(rows=3, cols=1)
    for cell in [np_tbl.rows[i].cells[0] for i in range(3)]:
        _shade(cell, "EAF6EE")
        _set_cell_border(cell, color="1A8754", sz="8")
    p1 = np_tbl.rows[0].cells[0].paragraphs[0]
    r = p1.add_run("Employee Net Pay"); r.bold = True; r.font.size = Pt(10)
    p2 = np_tbl.rows[1].cells[0].paragraphs[0]
    r2 = p2.add_run(_money(payslip.net))
    r2.bold = True; r2.font.size = Pt(18)
    r2.font.color.rgb = RGBColor(0x1A, 0x87, 0x54)
    p3 = np_tbl.rows[2].cells[0].paragraphs[0]
    r3 = p3.add_run(f"Paid Days: {payslip.days_worked:g}  |  LOP Days: {payslip.lop_days:g}")
    r3.font.size = Pt(9)

    doc.add_paragraph()

    
    earnings = [
        ("Basic", payslip.basic, "basic"),
        ("House Rent Allowance", payslip.hra, "hra"),
        ("Education Allowance", payslip.education_allowance, "education_allowance"),
        ("Leave and Travel Allowance", payslip.lta, "lta"),
        ("Personal Allowance", payslip.personal_allowance, "personal_allowance"),
    ]

    e_tbl = doc.add_table(rows=len(earnings) + 2, cols=3)
    hdr = e_tbl.rows[0].cells
    for i, h in enumerate(["EARNINGS", "MASTER", "ACTUAL"]):
        rr = hdr[i].paragraphs[0].add_run(h)
        rr.bold = True; rr.font.size = Pt(9)
        _shade(hdr[i], "F3F4F6")
    for idx, (label, amt, key) in enumerate(earnings, start=1):
        cells = e_tbl.rows[idx].cells
        cells[0].paragraphs[0].add_run(label).font.size = Pt(9)
        p = cells[1].paragraphs[0]; p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        p.add_run(_money(master_map.get(key, amt))).font.size = Pt(9)
        p2 = cells[2].paragraphs[0]; p2.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        p2.add_run(_money(amt)).font.size = Pt(9)
    foot_cells = e_tbl.rows[-1].cells
    rr = foot_cells[0].paragraphs[0].add_run("Gross Earnings"); rr.bold = True
    p = foot_cells[2].paragraphs[0]; p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    p.add_run(_money(payslip.gross)).bold = True
    for c in foot_cells:
        _shade(c, "FAFAFA")

    doc.add_paragraph()

    
    ded_rows = [
        ("Employee Contribution to PF", "employee_pf", payslip.employee_pf),
        ("Employer Contribution to PF", "employer_pf", payslip.employer_pf),
        ("Group Medical Insurance", "medical_insurance", payslip.medical_insurance),
    ]
    for d in payslip.extra_deductions:
        ded_rows.append((d.name, None, d.amount))
    d_tbl = doc.add_table(rows=len(ded_rows) + 2, cols=3)
    h = d_tbl.rows[0].cells
    for i, t in enumerate(["DEDUCTIONS", "MASTER", "ACTUAL"]):
        rr = h[i].paragraphs[0].add_run(t); rr.bold = True; rr.font.size = Pt(9)
        _shade(h[i], "F3F4F6")
    for idx, (label, key, amt) in enumerate(ded_rows, start=1):
        cells = d_tbl.rows[idx].cells
        cells[0].paragraphs[0].add_run(label).font.size = Pt(9)
        p = cells[1].paragraphs[0]; p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        master_val = master_map.get(key, amt) if key else amt
        p.add_run(_money(master_val)).font.size = Pt(9)
        p2 = cells[2].paragraphs[0]; p2.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        p2.add_run(_money(amt)).font.size = Pt(9)
    fc = d_tbl.rows[-1].cells
    rr = fc[0].paragraphs[0].add_run("Total Deductions"); rr.bold = True
    p = fc[2].paragraphs[0]; p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    p.add_run(_money(payslip.total_deductions)).bold = True
    for c in fc:
        _shade(c, "FAFAFA")

    doc.add_paragraph()

    
    np_tbl2 = doc.add_table(rows=2, cols=2)
    c1 = np_tbl2.rows[0].cells[0]
    c2 = np_tbl2.rows[0].cells[1]
    _shade(c1, "EAF6EE"); _shade(c2, "EAF6EE")
    rr = c1.paragraphs[0].add_run("TOTAL NET PAYABLE")
    rr.bold = True; rr.font.size = Pt(11)
    p = c2.paragraphs[0]; p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    rr2 = p.add_run(_money(payslip.net))
    rr2.bold = True; rr2.font.size = Pt(13)
    rr2.font.color.rgb = RGBColor(0x1A, 0x87, 0x54)

    nc1 = np_tbl2.rows[1].cells[0]
    nc1.merge(np_tbl2.rows[1].cells[1])
    p = nc1.paragraphs[0]
    rr = p.add_run("Amount in words: " + num_to_indian_words(payslip.net))
    rr.font.size = Pt(9); rr.italic = True

    doc.add_paragraph()
    foot = doc.add_paragraph()
    foot.alignment = WD_ALIGN_PARAGRAPH.CENTER
    fr = foot.add_run("-- This is a system-generated payslip and does not require a signature. --")
    fr.font.size = Pt(8)
    fr.font.color.rgb = RGBColor(0x88, 0x88, 0x88)

    buf = BytesIO()
    doc.save(buf)
    buf.seek(0)
    return buf
