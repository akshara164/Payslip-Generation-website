"""Convert a positive number to Indian-numbering English words."""

_ones = ["", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine",
         "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen",
         "Seventeen", "Eighteen", "Nineteen"]
_tens = ["", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"]


def _two(n):
    if n < 20:
        return _ones[n]
    return _tens[n // 10] + ("" if n % 10 == 0 else " " + _ones[n % 10])


def _three(n):
    h = n // 100
    r = n % 100
    out = ""
    if h:
        out = _ones[h] + " Hundred"
        if r:
            out += " " + _two(r)
    else:
        out = _two(r)
    return out


def num_to_indian_words(amount: float) -> str:
    rupees = int(amount)
    paise = round((amount - rupees) * 100)
    if rupees == 0:
        words = "Zero"
    else:
        crore = rupees // 10000000
        rupees %= 10000000
        lakh = rupees // 100000
        rupees %= 100000
        thousand = rupees // 1000
        rupees %= 1000
        hundred = rupees
        parts = []
        if crore:
            parts.append(_two(crore) + " Crore")
        if lakh:
            parts.append(_two(lakh) + " Lakh")
        if thousand:
            parts.append(_two(thousand) + " Thousand")
        if hundred:
            parts.append(_three(hundred))
        words = " ".join(parts)
    out = f"Indian Rupee {words} Only"
    if paise:
        out = f"Indian Rupee {words} and {_two(paise)} Paise Only"
    return out
