"""Payroll-related helpers: working days, salary calc."""
from calendar import monthrange
from datetime import date, timedelta
from config import Config


def working_days_in_month(year: int, month: int, holidays: list[date] | None = None) -> int:
    holidays = set(holidays or [])
    days = monthrange(year, month)[1]
    count = 0
    for d in range(1, days + 1):
        dt = date(year, month, d)
        if dt.weekday() < 5 and dt not in holidays:
            count += 1
    return count


def total_days_in_month(year: int, month: int) -> int:
    return monthrange(year, month)[1]


def compute_payslip(version, days_worked: float, lop_days: float, total_working_days: int,
                    extra_deductions: list[tuple[str, float]] | None = None) -> dict:
    extra_deductions = extra_deductions or []
    if total_working_days <= 0:
        ratio = 0.0
    else:
        ratio = max(0.0, min(1.0, days_worked / total_working_days))

    def pro(v):
        return round((v or 0) * ratio, 2)

    earnings = {
        "basic": pro(version.basic),
        "hra": pro(version.hra),
        "education_allowance": pro(version.education_allowance),
        "lta": pro(version.lta),
        "personal_allowance": pro(version.personal_allowance),
    }
    gross = round(sum(earnings.values()), 2)
    employee_pf = pro(version.employee_pf)
    employer_pf = pro(version.employer_pf)
    medical_insurance = pro(version.medical_insurance)
    extra_total = round(sum(a for _, a in extra_deductions), 2)
    total_ded = round(employee_pf + employer_pf + medical_insurance + extra_total, 2)
    net = round(gross - total_ded, 2)
    return {
        **earnings,
        "employee_pf": employee_pf,
        "employer_pf": employer_pf,
        "medical_insurance": medical_insurance,
        "lop_deduction": 0,
        "gross": gross,
        "total_deductions": total_ded,
        "net": net,
    }
