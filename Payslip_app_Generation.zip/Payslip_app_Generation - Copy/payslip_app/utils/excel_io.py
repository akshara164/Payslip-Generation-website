"""Excel import (employees) and export (salary report)."""
from io import BytesIO
from datetime import datetime, date
from calendar import month_name

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side


EMPLOYEE_COLUMNS = [
    "Employee ID", "Employee Name", "Designation", "Department",
    "Date of Joining", "Bank Account Number", "UAN Number",
    "Email", "Work Location", "Status",
]


def build_employee_template() -> BytesIO:
    wb = Workbook()
    ws = wb.active
    ws.title = "Employees"
    ws.append(EMPLOYEE_COLUMNS)
    for cell in ws[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="1f3a5f")
        cell.alignment = Alignment(horizontal="center")
    for col in ws.columns:
        ws.column_dimensions[col[0].column_letter].width = 22
    buf = BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf


def parse_employee_excel(file_storage):
    """Returns list[dict] ready for Employee creation, plus list of errors."""
    wb = load_workbook(file_storage, data_only=True)
    ws = wb.active
    headers = [c.value for c in ws[1]]
    missing = [c for c in EMPLOYEE_COLUMNS if c not in headers]
    if missing:
        return [], [f"Missing columns: {', '.join(missing)}"]
    idx = {c: headers.index(c) for c in EMPLOYEE_COLUMNS}
    rows, errors = [], []
    for r_i, row in enumerate(ws.iter_rows(min_row=2, values_only=True), start=2):
        if all(v is None or v == "" for v in row):
            continue
        try:
            doj_raw = row[idx["Date of Joining"]]
            if isinstance(doj_raw, datetime):
                doj = doj_raw.date()
            elif isinstance(doj_raw, date):
                doj = doj_raw
            else:
                doj = datetime.strptime(str(doj_raw), "%Y-%m-%d").date()
            status = str(row[idx["Status"]]).strip()
            if status not in ("Active", "Inactive", "On Notice"):
                raise ValueError(f"invalid status '{status}'")
            rows.append({
                "employee_id": str(row[idx["Employee ID"]]).strip(),
                "name": str(row[idx["Employee Name"]]).strip(),
                "designation": str(row[idx["Designation"]]).strip(),
                "department": str(row[idx["Department"]]).strip(),
                "date_of_joining": doj,
                "bank_account": str(row[idx["Bank Account Number"]] or "").strip(),
                "uan_number": str(row[idx["UAN Number"]] or "").strip(),
                "email": str(row[idx["Email"]] or "").strip(),
                "work_location": str(row[idx["Work Location"]] or "").strip(),
                "status": status,
            })
        except Exception as e:
            errors.append(f"Row {r_i}: {e}")
    return rows, errors


def build_salary_report(run, payslips) -> BytesIO:
    wb = Workbook()
    ws = wb.active
    ws.title = f"{month_name[run.month]} {run.year}"

    headers = [
        "Employee Name", "Employee ID", "Designation", "Department", "Salary Month",
        "Total Working Days", "Days Worked", "Leaves", "LOP Days",
        "Gross Earnings", "Total Deductions", "Net Pay",
    ]
    ws.append(headers)
    head_fill = PatternFill("solid", fgColor="1f3a5f")
    border = Border(*[Side(style="thin", color="DDDDDD")] * 4)
    for cell in ws[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = head_fill
        cell.alignment = Alignment(horizontal="center")
        cell.border = border

    salary_month = f"{month_name[run.month]} {run.year}"
    for p in payslips:
        emp = p.employee
        ws.append([
            emp.name, emp.employee_id, emp.designation, emp.department, salary_month,
            run.total_working_days, p.days_worked, p.leaves, p.lop_days,
            p.gross, p.total_deductions, p.net,
        ])

    
    last = ws.max_row
    if last > 1:
        ws.append(["", "", "", "", "TOTAL", "", "", "", "",
                   f"=SUM(J2:J{last})", f"=SUM(K2:K{last})", f"=SUM(L2:L{last})"])
        for cell in ws[ws.max_row]:
            cell.font = Font(bold=True)

    for col in ws.columns:
        ws.column_dimensions[col[0].column_letter].width = 18
        for cell in col:
            cell.border = border
    for row in ws.iter_rows(min_row=2, min_col=10, max_col=12):
        for cell in row:
            cell.number_format = "#,##0.00"

    buf = BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf
