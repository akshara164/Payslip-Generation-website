import os
from flask import Flask, redirect, url_for

from config import Config
from models import db
from routes.auth import bp as auth_bp
from routes.dashboard import bp as dashboard_bp
from routes.employees import bp as employees_bp
from routes.salary import bp as salary_bp
from routes.payroll import bp as payroll_bp
from routes.holidays import bp as holidays_bp


def create_app():
    app = Flask(__name__, instance_relative_config=False)
    app.config.from_object(Config)
    os.makedirs(os.path.join(os.path.dirname(__file__), "instance"), exist_ok=True)
    os.makedirs(Config.EXPORT_DIR, exist_ok=True)
    db.init_app(app)

    app.register_blueprint(auth_bp)
    app.register_blueprint(dashboard_bp)
    app.register_blueprint(employees_bp)
    app.register_blueprint(salary_bp)
    app.register_blueprint(payroll_bp)
    app.register_blueprint(holidays_bp)

    @app.route("/")
    def root():
        return redirect(url_for("dashboard.index"))

    with app.app_context():
        db.create_all()
        
        try:
            from sqlalchemy import text
            cols = [r[1] for r in db.session.execute(text("PRAGMA table_info(payslips)")).fetchall()]
            if "lop_deduction" not in cols:
                db.session.execute(text("ALTER TABLE payslips ADD COLUMN lop_deduction FLOAT DEFAULT 0"))
                db.session.commit()
        except Exception:
            db.session.rollback()

    return app


app = create_app()


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
