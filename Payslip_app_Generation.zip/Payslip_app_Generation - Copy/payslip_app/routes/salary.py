from datetime import datetime, date
from flask import Blueprint, render_template, request, redirect, url_for, flash
from models import db, Employee, SalaryVersion
from .auth import login_required

bp = Blueprint("salary", __name__, url_prefix="/employees/<int:emp_pk>/salary")

FIELDS = ["basic", "hra", "education_allowance", "lta", "personal_allowance",
          "employee_pf", "employer_pf", "medical_insurance"]


def _parse_extras(form):
    names = form.getlist("extra_name")
    amounts = form.getlist("extra_amount")
    items = []
    for n, a in zip(names, amounts):
        n = (n or "").strip()
        if not n:
            continue
        try:
            items.append(f"{n}:{float(a or 0)}")
        except ValueError:
            pass
    return ";".join(items)


def _next_version_no(emp):
    return (max((v.version_no for v in emp.salary_versions), default=0) + 1)


@bp.route("/")
@login_required
def index(emp_pk):
    emp = Employee.query.get_or_404(emp_pk)
    versions = sorted(emp.salary_versions, key=lambda v: v.version_no, reverse=True)
    
    others = (
        Employee.query.filter(Employee.id != emp.id).order_by(Employee.name).all()
    )
    copy_sources = []
    for o in others:
        sal = o.current_salary()
        if sal is not None:
            copy_sources.append((o, sal))
    return render_template(
        "salary/index.html",
        employee=emp,
        versions=versions,
        copy_sources=copy_sources,
    )


@bp.route("/new", methods=["GET", "POST"])
@login_required
def new(emp_pk):
    emp = Employee.query.get_or_404(emp_pk)
    base = emp.current_salary()
    if request.method == "POST":
        v = SalaryVersion(employee_pk=emp.id, version_no=_next_version_no(emp))
        v.effective_date = datetime.strptime(request.form["effective_date"], "%Y-%m-%d").date()
        for f in FIELDS:
            setattr(v, f, float(request.form.get(f) or 0))
        v.extra_deductions = _parse_extras(request.form)
        if request.form.get("is_current") == "on":
            for ov in emp.salary_versions:
                ov.is_current = False
            v.is_current = True
        elif not emp.salary_versions:
            v.is_current = True
        db.session.add(v)
        db.session.commit()
        flash(f"Saved Version {v.version_no}.", "success")
        return redirect(url_for("salary.index", emp_pk=emp.id))
    return render_template("salary/form.html", employee=emp, version=None, base=base, fields=FIELDS)


@bp.route("/<int:vid>/edit", methods=["GET", "POST"])
@login_required
def edit(emp_pk, vid):
    emp = Employee.query.get_or_404(emp_pk)
    v = SalaryVersion.query.get_or_404(vid)
    if request.method == "POST":
        v.effective_date = datetime.strptime(request.form["effective_date"], "%Y-%m-%d").date()
        for f in FIELDS:
            setattr(v, f, float(request.form.get(f) or 0))
        v.extra_deductions = _parse_extras(request.form)
        if request.form.get("is_current") == "on":
            for ov in emp.salary_versions:
                ov.is_current = False
            v.is_current = True
        db.session.commit()
        flash("Version updated.", "success")
        return redirect(url_for("salary.index", emp_pk=emp.id))
    return render_template("salary/form.html", employee=emp, version=v, base=v, fields=FIELDS)


@bp.route("/<int:vid>/set-current", methods=["POST"])
@login_required
def set_current(emp_pk, vid):
    emp = Employee.query.get_or_404(emp_pk)
    for ov in emp.salary_versions:
        ov.is_current = (ov.id == vid)
    db.session.commit()
    flash("Current version updated.", "success")
    return redirect(url_for("salary.index", emp_pk=emp.id))


@bp.route("/copy-from/<int:src_emp_pk>", methods=["POST"])
@login_required
def copy_from(emp_pk, src_emp_pk):
    emp = Employee.query.get_or_404(emp_pk)
    src = Employee.query.get_or_404(src_emp_pk)
    src_sal = src.current_salary()
    if not src_sal:
        flash(f"{src.name} has no salary version to copy.", "error")
        return redirect(url_for("salary.index", emp_pk=emp.id))
    v = SalaryVersion(employee_pk=emp.id, version_no=_next_version_no(emp))
    v.effective_date = date.today()
    for f in FIELDS:
        setattr(v, f, getattr(src_sal, f) or 0)
    v.extra_deductions = src_sal.extra_deductions or ""
    if not emp.salary_versions:
        v.is_current = True
    else:
        for ov in emp.salary_versions:
            ov.is_current = False
        v.is_current = True
    db.session.add(v)
    db.session.commit()
    flash(f"Copied salary from {src.name} as Version {v.version_no}.", "success")
    return redirect(url_for("salary.index", emp_pk=emp.id))
