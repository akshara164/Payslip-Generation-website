from datetime import datetime, date
from calendar import month_name
from flask import Blueprint, render_template, request, redirect, url_for, flash, send_file, abort
from sqlalchemy import extract, func

from models import db, Employee, PayrollRun, Payslip, PayslipDeduction, PublicHoliday, SalaryVersion, Holiday
from utils.payroll_calc import working_days_in_month, total_days_in_month, compute_payslip
from utils.pdf_payslip import build_payslip_pdf
from utils.docx_payslip import build_payslip_docx
from utils.excel_io import build_salary_report
from config import Config
from .auth import login_required

bp = Blueprint("payroll", __name__, url_prefix="/payroll")


@bp.route("/")
@login_required
def index():
    runs = PayrollRun.query.order_by(PayrollRun.year.desc(), PayrollRun.month.desc()).all()
    return render_template("payroll/index.html", runs=runs, month_name=month_name)


@bp.route("/run", methods=["GET", "POST"])
@login_required
def run_new():
    if request.method == "POST":
        month = int(request.form["month"])
        year = int(request.form["year"])
        if PayrollRun.query.filter_by(month=month, year=year).first():
            flash("A payroll run for that period already exists.", "error")
            return redirect(url_for("payroll.index"))
        # Holidays: merge global Holiday calendar (matching this month) + manually-entered ones
        holidays = []
        seen_dates = set()
        for gh in Holiday.query.all():
            if gh.holiday_date.year == year and gh.holiday_date.month == month:
                holidays.append((gh.holiday_date, gh.name))
                seen_dates.add(gh.holiday_date)
        for hdate, hname in zip(request.form.getlist("holiday_date"), request.form.getlist("holiday_name")):
            if hdate:
                try:
                    d = datetime.strptime(hdate, "%Y-%m-%d").date()
                    if d in seen_dates:
                        continue
                    holidays.append((d, hname.strip()))
                    seen_dates.add(d)
                except ValueError:
                    pass
        wd = working_days_in_month(year, month, [h[0] for h in holidays])
        run = PayrollRun(month=month, year=year, total_working_days=wd)
        db.session.add(run)
        db.session.flush()
        for d, n in holidays:
            db.session.add(PublicHoliday(run_id=run.id, holiday_date=d, name=n))

        
        period_end = date(year, month, total_days_in_month(year, month))
        actives = [e for e in Employee.query.filter_by(status="Active").all()
                   if e.date_of_joining and e.date_of_joining <= period_end]
        skipped = []
        for emp in actives:
            sv = emp.current_salary(date(year, month, 1))
            if not sv:
                skipped.append(emp.name)
                continue
            extras = list(sv.extra_deduction_items)
            comp = compute_payslip(sv, wd, 0, wd, extras)
            ps = Payslip(
                run_id=run.id, employee_pk=emp.id, salary_version_id=sv.id,
                days_worked=wd, leaves=0, lop_days=0,
                pay_date=date(year, month, total_days_in_month(year, month)),
                status="Draft", **{k: comp[k] for k in
                    ("basic","hra","education_allowance","lta","personal_allowance",
                     "employee_pf","employer_pf","medical_insurance","lop_deduction","gross","total_deductions","net")}
            )
            db.session.add(ps)
            db.session.flush()
            for n, a in extras:
                db.session.add(PayslipDeduction(payslip_id=ps.id, name=n, amount=a))
        db.session.commit()
        msg = f"Payroll run created with {len(actives) - len(skipped)} draft payslip(s)."
        if skipped:
            msg += f" Skipped (no salary): {', '.join(skipped)}"
        flash(msg, "success")
        return redirect(url_for("payroll.detail", run_id=run.id))

    today = date.today()
    global_holidays = [
        {"date": h.holiday_date.isoformat(), "name": h.name}
        for h in Holiday.query.order_by(Holiday.holiday_date.asc()).all()
    ]
    return render_template("payroll/new.html",
                           month_name=month_name,
                           default_month=today.month,
                           default_year=today.year,
                           global_holidays=global_holidays)


@bp.route("/<int:run_id>")
@login_required
def detail(run_id):
    run = PayrollRun.query.get_or_404(run_id)
    # Auto-sync: create draft payslips for any active employees missing from this run
    existing_emp_ids = {p.employee_pk for p in run.payslips}
    period_end = date(run.year, run.month, total_days_in_month(run.year, run.month))
    actives = [e for e in Employee.query.filter_by(status="Active").all()
               if e.date_of_joining and e.date_of_joining <= period_end]
    added = []
    skipped = []
    wd = run.total_working_days
    for emp in actives:
        if emp.id in existing_emp_ids:
            continue
        sv = emp.current_salary(date(run.year, run.month, 1))
        if not sv:
            skipped.append(emp.name)
            continue
        extras = list(sv.extra_deduction_items)
        comp = compute_payslip(sv, wd, 0, wd, extras)
        ps = Payslip(
            run_id=run.id, employee_pk=emp.id, salary_version_id=sv.id,
            days_worked=wd, leaves=0, lop_days=0,
            pay_date=date(run.year, run.month, total_days_in_month(run.year, run.month)),
            status="Draft", **{k: comp[k] for k in
                ("basic","hra","education_allowance","lta","personal_allowance",
                 "employee_pf","employer_pf","medical_insurance","lop_deduction","gross","total_deductions","net")}
        )
        db.session.add(ps)
        db.session.flush()
        for n, a in extras:
            db.session.add(PayslipDeduction(payslip_id=ps.id, name=n, amount=a))
        added.append(emp.name)
    if added or skipped:
        db.session.commit()
        if added:
            flash(f"Added draft payslip(s) for new employee(s): {', '.join(added)}", "success")
        if skipped:
            flash(f"Skipped (no salary set): {', '.join(skipped)}", "error")
    payslips = sorted(run.payslips, key=lambda p: p.employee.name)
    return render_template("payroll/detail.html", run=run, payslips=payslips, month_name=month_name)


@bp.route("/<int:run_id>/working-days", methods=["POST"])
@login_required
def update_working_days(run_id):
    run = PayrollRun.query.get_or_404(run_id)
    try:
        run.total_working_days = int(request.form["total_working_days"])
        db.session.commit()
        
        for p in run.payslips:
            if p.status == "Draft":
                p.days_worked = max(0.0, run.total_working_days - (p.leaves or 0) - (p.lop_days or 0))
                comp = compute_payslip(p.salary_version, p.days_worked, p.lop_days, run.total_working_days,
                                       [(d.name, d.amount) for d in p.extra_deductions])
                for k, v in comp.items():
                    setattr(p, k, v)
        db.session.commit()
        flash("Working days updated and drafts recalculated.", "success")
    except Exception as e:
        flash(f"Error: {e}", "error")
    return redirect(url_for("payroll.detail", run_id=run_id))


@bp.route("/payslip/<int:psid>", methods=["GET", "POST"])
@login_required
def payslip_edit(psid):
    p = Payslip.query.get_or_404(psid)
    run = p.run
    if request.method == "POST":
        if p.status == "Finalized":
            flash("Payslip is finalized. Unlock it first.", "error")
            return redirect(url_for("payroll.payslip_edit", psid=psid))
        p.leaves = float(request.form.get("leaves") or 0)
        p.lop_days = float(request.form.get("lop_days") or 0)
        p.days_worked = max(0.0, run.total_working_days - p.leaves - p.lop_days)
        
        for d in list(p.extra_deductions):
            db.session.delete(d)
        names = request.form.getlist("extra_name")
        amounts = request.form.getlist("extra_amount")
        extras = []
        for n, a in zip(names, amounts):
            n = (n or "").strip()
            if not n:
                continue
            try:
                amt = float(a or 0)
                db.session.add(PayslipDeduction(payslip_id=p.id, name=n, amount=amt))
                extras.append((n, amt))
            except ValueError:
                pass
        comp = compute_payslip(p.salary_version, p.days_worked, p.lop_days, run.total_working_days, extras)
        for k, v in comp.items():
            setattr(p, k, v)
        db.session.commit()
        flash("Payslip updated.", "success")
        return redirect(url_for("payroll.detail", run_id=run.id))
    return render_template("payroll/payslip_edit.html", p=p, run=run, month_name=month_name)


@bp.route("/<int:run_id>/delete", methods=["POST"])
@login_required
def delete_run(run_id):
    run = PayrollRun.query.get_or_404(run_id)
    label = f"{month_name[run.month]} {run.year}"
    for p in list(run.payslips):
        for d in list(p.extra_deductions):
            db.session.delete(d)
        db.session.delete(p)
    for h in list(run.holidays):
        db.session.delete(h)
    db.session.delete(run)
    db.session.commit()
    flash(f"Payroll run for {label} deleted.", "success")
    return redirect(url_for("payroll.index"))


@bp.route("/payslip/<int:psid>/finalize", methods=["POST"])
@login_required
def finalize(psid):
    p = Payslip.query.get_or_404(psid)
    p.status = "Finalized"
    db.session.commit()
    flash("Payslip finalized.", "success")
    return redirect(url_for("payroll.detail", run_id=p.run_id))


@bp.route("/payslip/<int:psid>/unlock", methods=["POST"])
@login_required
def unlock(psid):
    p = Payslip.query.get_or_404(psid)
    p.status = "Draft"
    db.session.commit()
    flash("Payslip unlocked.", "success")
    return redirect(url_for("payroll.detail", run_id=p.run_id))


@bp.route("/payslip/<int:psid>/view")
@login_required
def payslip_view(psid):
    from utils.num_words import num_to_indian_words
    p = Payslip.query.get_or_404(psid)
    return render_template(
        "payroll/payslip_view.html",
        p=p,
        run=p.run,
        employee=p.employee,
        master=_master_map(p),
        company_name=Config.COMPANY_NAME,
        company_address=Config.COMPANY_ADDRESS,
        amount_words=num_to_indian_words(p.net),
        month_name=month_name,
    )



def _master_map(payslip):
    """Return the un-prorated 'Master' amounts from the linked salary version."""
    sv = payslip.salary_version
    fields = ("basic", "hra", "education_allowance", "lta", "personal_allowance",
              "employee_pf", "employer_pf", "medical_insurance")
    out = {f: 0.0 for f in fields}
    if sv:
        for f in fields:
            out[f] = float(getattr(sv, f) or 0)
    return out



@bp.route("/payslip/<int:psid>/pdf")
@login_required
def payslip_pdf(psid):
    p = Payslip.query.get_or_404(psid)
    if p.status != "Finalized":
        flash("Finalize the payslip before downloading the PDF.", "error")
        return redirect(url_for("payroll.payslip_edit", psid=psid))
    buf = build_payslip_pdf(p, p.employee, p.run, Config.COMPANY_NAME, Config.COMPANY_ADDRESS, _master_map(p))
    safe_name = "".join(c for c in p.employee.name if c.isalnum())
    fname = f"{safe_name}_{month_name[p.run.month]}_{p.run.year}.pdf"
    return send_file(buf, as_attachment=True, download_name=fname, mimetype="application/pdf")


def _send_payslip_email(p, to_email):
    """Build PDF + HTML email with Elverve logo and send. Returns (ok, error_message)."""
    import smtplib, ssl, os, mimetypes
    from email.message import EmailMessage

    buf = build_payslip_pdf(p, p.employee, p.run, Config.COMPANY_NAME, Config.COMPANY_ADDRESS, _master_map(p))
    safe_name = "".join(c for c in p.employee.name if c.isalnum())
    fname = f"{safe_name}_{month_name[p.run.month]}_{p.run.year}.pdf"
    period = f"{month_name[p.run.month]} {p.run.year}"

    msg = EmailMessage()
    msg["Subject"] = f"Payslip - {period} - {p.employee.name}"
    msg["From"] = Config.SMTP_FROM
    msg["To"] = to_email
    msg.set_content(
        f"Dear {p.employee.name},\n\n"
        f"Please find attached your payslip for {period}.\n\n"
        f"Regards,\n{Config.COMPANY_NAME}"
    )

    logo_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "static", "elverve_logo.png")
    logo_cid = "elverve_logo"
    logo_html = ""
    logo_bytes = None
    if os.path.exists(logo_path):
        with open(logo_path, "rb") as f:
            logo_bytes = f.read()
        logo_html = f'<br/><img src="cid:{logo_cid}" alt="Elverve" style="max-width:160px;height:auto;margin-top:8px;"/>'

    html_body = f"""\
<html><body style="font-family:Arial,sans-serif;color:#222;">
  <p>Dear {p.employee.name},</p>
  <p>Please find attached your payslip for <strong>{period}</strong>.</p>
  <p>Regards,<br/><strong>{Config.COMPANY_NAME}</strong>{logo_html}</p>
</body></html>"""
    msg.add_alternative(html_body, subtype="html")
    if logo_bytes:
        
        html_part = msg.get_payload()[-1]
        html_part.add_related(logo_bytes, maintype="image", subtype="png", cid=f"<{logo_cid}>", filename="elverve_logo.png")

    msg.add_attachment(buf.getvalue(), maintype="application", subtype="pdf", filename=fname)

    try:
        if not Config.SMTP_USER or not Config.SMTP_PASSWORD:
            return False, "SMTP credentials are not configured."
        with smtplib.SMTP(Config.SMTP_HOST, Config.SMTP_PORT, timeout=30) as smtp:
            smtp.ehlo()
            if Config.SMTP_USE_TLS:
                smtp.starttls(context=ssl.create_default_context())
                smtp.ehlo()
            smtp.login(Config.SMTP_USER, Config.SMTP_PASSWORD)
            smtp.send_message(msg)
        return True, None
    except Exception as e:
        return False, str(e)


@bp.route("/payslip/<int:psid>/send_mail", methods=["GET", "POST"])
@login_required
def payslip_send_mail(psid):
    p = Payslip.query.get_or_404(psid)
    if p.status != "Finalized":
        flash("Finalize the payslip before sending by email.", "error")
        return redirect(url_for("payroll.payslip_edit", psid=psid))

    if request.method == "POST":
        to_email = (request.form.get("email") or "").strip()
        if not to_email or "@" not in to_email:
            flash("Please enter a valid email address.", "error")
            return redirect(url_for("payroll.payslip_send_mail", psid=psid))

        ok, err = _send_payslip_email(p, to_email)
        if ok:
            flash(f"Payslip emailed to {to_email}.", "success")
            return redirect(url_for("payroll.detail", run_id=p.run_id))
        flash(f"Failed to send email: {err}", "error")
        return redirect(url_for("payroll.payslip_send_mail", psid=psid))

    default_email = getattr(p.employee, "email", "") or ""
    return render_template("payroll/send_mail.html", p=p, default_email=default_email,
                           period=f"{month_name[p.run.month]} {p.run.year}")


@bp.route("/<int:run_id>/send_mail_finalized", methods=["POST"])
@login_required
def send_mail_finalized(run_id):
    run = PayrollRun.query.get_or_404(run_id)
    finalized = [p for p in run.payslips if p.status == "Finalized"]
    if not finalized:
        flash("No finalized payslips in this run.", "error")
        return redirect(url_for("payroll.detail", run_id=run_id))

    sent, no_email, failed = [], [], []
    for p in finalized:
        to_email = (getattr(p.employee, "email", "") or "").strip()
        if not to_email or "@" not in to_email:
            no_email.append(p.employee.name)
            continue
        ok, err = _send_payslip_email(p, to_email)
        if ok:
            sent.append(p.employee.name)
        else:
            failed.append(f"{p.employee.name} ({err})")

    if sent:
        flash(f"Sent payslip to {len(sent)} employee(s): {', '.join(sent)}", "success")
    if no_email:
        flash(f"Skipped (no email on file): {', '.join(no_email)}", "error")
    if failed:
        flash(f"Failed: {', '.join(failed)}", "error")
    return redirect(url_for("payroll.detail", run_id=run_id))



@bp.route("/<int:run_id>/export.xlsx")
@login_required
def export_excel(run_id):
    run = PayrollRun.query.get_or_404(run_id)
    finalized = [p for p in run.payslips if p.status == "Finalized"]
    if not finalized:
        flash("No finalized payslips to export.", "error")
        return redirect(url_for("payroll.detail", run_id=run_id))
    buf = build_salary_report(run, finalized)
    fname = f"Salary_Report_{month_name[run.month]}_{run.year}.xlsx"
    return send_file(buf, as_attachment=True, download_name=fname,
                     mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
