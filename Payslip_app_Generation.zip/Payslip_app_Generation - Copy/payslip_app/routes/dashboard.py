from datetime import date
from calendar import month_name, monthrange
from flask import Blueprint, render_template, request
from models import db, Employee, PayrollRun, Payslip
from .auth import login_required

bp = Blueprint("dashboard", __name__)


def _previous_month(year: int, month: int):
    return (year, month - 1) if month > 1 else (year - 1, 12)


@bp.route("/")
@login_required
def index():
    today = date.today()
    try:
        month = int(request.args.get("month", today.month))
        year = int(request.args.get("year", today.year))
    except (TypeError, ValueError):
        month, year = today.month, today.year
    month = max(1, min(12, month))

    period_end = date(year, month, monthrange(year, month)[1])

    
    emps_in_period = [e for e in Employee.query.all()
                      if e.date_of_joining and e.date_of_joining <= period_end]
    total_employees = len(emps_in_period)
    active_employees = sum(1 for e in emps_in_period if e.status == "Active")

    
    run = PayrollRun.query.filter_by(month=month, year=year).first()
    if run:
        payslips_generated = len(run.payslips)
        total_payroll = round(sum((p.net or 0) for p in run.payslips), 2)
        pending_approvals = sum(1 for p in run.payslips if p.status == "Draft")
    else:
        payslips_generated = 0
        total_payroll = 0.0
        pending_approvals = 0

    
    prev_y, prev_m = _previous_month(year, month)
    prev_run = PayrollRun.query.filter_by(month=prev_m, year=prev_y).first()
    prev_payroll = round(sum((p.net or 0) for p in prev_run.payslips), 2) if prev_run else 0.0
    if prev_payroll > 0:
        payroll_delta_pct = round(((total_payroll - prev_payroll) / prev_payroll) * 100, 2)
    else:
        payroll_delta_pct = None

    
    new_this_month = sum(
        1 for e in emps_in_period
        if e.date_of_joining and e.date_of_joining.year == year
        and e.date_of_joining.month == month
    )

    active_pct = round((active_employees / total_employees) * 100, 2) if total_employees else 0.0
    completed_pct = round((payslips_generated / active_employees) * 100, 2) if active_employees else 0.0

    stats = {
        "total_employees": total_employees,
        "active_employees": active_employees,
        "total_payroll": total_payroll,
        "payslips_generated": payslips_generated,
        "pending_approvals": pending_approvals,
        "new_this_month": new_this_month,
        "active_pct": active_pct,
        "completed_pct": completed_pct,
        "payroll_delta_pct": payroll_delta_pct,
        "prev_period_label": f"{month_name[prev_m][:3]} {prev_y}",
        "period_label": f"{month_name[month]} {year}",
    }

    
    options = []
    y, m = today.year, today.month
    for _ in range(24):
        options.append({"month": m, "year": y, "label": f"{month_name[m]} {y}"})
        y, m = _previous_month(y, m)

    recent_runs = PayrollRun.query.order_by(
        PayrollRun.year.desc(), PayrollRun.month.desc()
    ).limit(5).all()

    return render_template(
        "dashboard.html",
        stats=stats,
        recent_runs=recent_runs,
        today=today,
        selected_month=month,
        selected_year=year,
        month_options=options,
    )
