from datetime import datetime
from flask import Blueprint, render_template, request, redirect, url_for, flash
from models import db, Holiday
from .auth import login_required

bp = Blueprint("holidays", __name__, url_prefix="/holidays")


@bp.route("/")
@login_required
def index():
    items = Holiday.query.order_by(Holiday.holiday_date.asc()).all()
    return render_template("holidays/index.html", items=items)


@bp.route("/add", methods=["POST"])
@login_required
def add():
    d = request.form.get("holiday_date")
    n = (request.form.get("name") or "").strip()
    if not d or not n:
        flash("Date and name are required.", "error")
        return redirect(url_for("holidays.index"))
    try:
        date_val = datetime.strptime(d, "%Y-%m-%d").date()
    except ValueError:
        flash("Invalid date.", "error")
        return redirect(url_for("holidays.index"))
    if Holiday.query.filter_by(holiday_date=date_val).first():
        flash("A holiday on that date already exists.", "error")
        return redirect(url_for("holidays.index"))
    db.session.add(Holiday(holiday_date=date_val, name=n))
    db.session.commit()
    flash("Holiday added.", "success")
    return redirect(url_for("holidays.index"))


@bp.route("/<int:hid>/delete", methods=["POST"])
@login_required
def delete(hid):
    h = Holiday.query.get_or_404(hid)
    db.session.delete(h)
    db.session.commit()
    flash("Holiday removed.", "success")
    return redirect(url_for("holidays.index"))
