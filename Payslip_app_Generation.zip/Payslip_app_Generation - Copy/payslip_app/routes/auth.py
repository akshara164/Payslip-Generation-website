from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from functools import wraps
from config import Config

bp = Blueprint("auth", __name__)


def login_required(view):
    @wraps(view)
    def wrapper(*a, **kw):
        if not session.get("hr_user"):
            return redirect(url_for("auth.login", next=request.path))
        return view(*a, **kw)
    return wrapper


@bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        u = request.form.get("username", "").strip()
        p = request.form.get("password", "")
        if u == Config.HR_USERNAME and p == Config.HR_PASSWORD:
            session["hr_user"] = u
            flash("Welcome back!", "success")
            nxt = request.args.get("next") or url_for("dashboard.index")
            return redirect(nxt)
        flash("Invalid credentials.", "error")
    return render_template("login.html")


@bp.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("auth.login"))
