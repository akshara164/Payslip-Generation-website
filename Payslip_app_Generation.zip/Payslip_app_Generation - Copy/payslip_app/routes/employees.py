from datetime import datetime, date
from io import BytesIO
from flask import (
    Blueprint, render_template, request, redirect, url_for, flash, send_file
)
from models import db, Employee, EmployeeChangeLog
from utils.excel_io import build_employee_template, parse_employee_excel
from .auth import login_required

bp = Blueprint("employees", __name__, url_prefix="/employees")

STATUSES = ["Active", "Inactive", "On Notice"]


@bp.route("/")
@login_required
def list_view():
    q = request.args.get("q", "").strip()
    status = request.args.get("status", "")
    query = Employee.query
    if q:
        like = f"%{q}%"
        query = query.filter(db.or_(Employee.name.ilike(like),
                                    Employee.employee_id.ilike(like),
                                    Employee.department.ilike(like)))
    if status:
        query = query.filter_by(status=status)
    employees = query.order_by(Employee.name).all()
    return render_template("employees/list.html", employees=employees, q=q, status=status, statuses=STATUSES)


def _form_to_employee(form, emp=None):
    is_new = emp is None
    if is_new:
        emp = Employee()
    new_des = form["designation"].strip()
    new_dep = form["department"].strip()
    if not is_new:
        if emp.designation != new_des:
            db.session.add(EmployeeChangeLog(employee_pk=emp.id, field="designation",
                                             old_value=emp.designation, new_value=new_des))
        if emp.department != new_dep:
            db.session.add(EmployeeChangeLog(employee_pk=emp.id, field="department",
                                             old_value=emp.department, new_value=new_dep))
    emp.employee_id = form["employee_id"].strip()
    emp.name = form["name"].strip()
    emp.designation = new_des
    emp.department = new_dep
    emp.date_of_joining = datetime.strptime(form["date_of_joining"], "%Y-%m-%d").date()
    emp.bank_account = form.get("bank_account", "").strip()
    emp.uan_number = form.get("uan_number", "").strip()
    emp.email = form.get("email", "").strip()
    emp.work_location = form.get("work_location", "").strip()
    emp.status = form.get("status", "Active")
    return emp


@bp.route("/new", methods=["GET", "POST"])
@login_required
def new():
    if request.method == "POST":
        try:
            new_eid = request.form["employee_id"].strip()
            if Employee.query.filter_by(employee_id=new_eid).first():
                flash(f"Employee ID '{new_eid}' already exists.", "error")
                return render_template("employees/form.html", employee=None,
                                       statuses=STATUSES, form_data=request.form)
            emp = _form_to_employee(request.form)
            db.session.add(emp)
            db.session.commit()
            flash("Employee added.", "success")
            return redirect(url_for("employees.list_view"))
        except Exception as e:
            db.session.rollback()
            flash(f"Error: {e}", "error")
    return render_template("employees/form.html", employee=None, statuses=STATUSES)


@bp.route("/<int:emp_pk>/edit", methods=["GET", "POST"])
@login_required
def edit(emp_pk):
    emp = Employee.query.get_or_404(emp_pk)
    if request.method == "POST":
        try:
            new_eid = request.form["employee_id"].strip()
            dup = Employee.query.filter(Employee.employee_id == new_eid,
                                        Employee.id != emp.id).first()
            if dup:
                flash(f"Employee ID '{new_eid}' already exists.", "error")
                return render_template("employees/form.html", employee=emp, statuses=STATUSES)
            _form_to_employee(request.form, emp)
            db.session.commit()
            flash("Employee updated.", "success")
            return redirect(url_for("employees.list_view"))
        except Exception as e:
            db.session.rollback()
            flash(f"Error: {e}", "error")
    return render_template("employees/form.html", employee=emp, statuses=STATUSES)


@bp.route("/<int:emp_pk>")
@login_required
def detail(emp_pk):
    emp = Employee.query.get_or_404(emp_pk)
    return render_template("employees/detail.html", employee=emp)


@bp.route("/<int:emp_pk>/delete", methods=["POST"])
@login_required
def delete(emp_pk):
    emp = Employee.query.get_or_404(emp_pk)
    try:
        db.session.delete(emp)
        db.session.commit()
        flash(f"Employee {emp.name} deleted.", "success")
    except Exception as e:
        db.session.rollback()
        flash(f"Error deleting employee: {e}", "error")
    return redirect(url_for("employees.list_view"))


@bp.route("/template.xlsx")
@login_required
def download_template():
    buf = build_employee_template()
    return send_file(buf, as_attachment=True, download_name="employee_template.xlsx",
                     mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


@bp.route("/import", methods=["GET", "POST"])
@login_required
def bulk_import():
    if request.method == "POST":
        f = request.files.get("file")
        if not f:
            flash("Please choose a file.", "error")
            return redirect(url_for("employees.bulk_import"))
        rows, errors = parse_employee_excel(f)
        added = 0
        for r in rows:
            if Employee.query.filter_by(employee_id=r["employee_id"]).first():
                errors.append(f"Skipped duplicate Employee ID {r['employee_id']}")
                continue
            db.session.add(Employee(**r))
            added += 1
        db.session.commit()
        flash(f"Imported {added} employees. {len(errors)} issue(s).", "success" if added else "error")
        return render_template("employees/import.html", errors=errors)
    return render_template("employees/import.html", errors=None)
