from datetime import date
from . import db


class SalaryVersion(db.Model):
    __tablename__ = "salary_versions"

    id = db.Column(db.Integer, primary_key=True)
    employee_pk = db.Column(db.Integer, db.ForeignKey("employees.id"), nullable=False)
    version_no = db.Column(db.Integer, nullable=False)
    effective_date = db.Column(db.Date, nullable=False, default=date.today)
    is_current = db.Column(db.Boolean, default=False)

    
    basic = db.Column(db.Float, default=0)
    hra = db.Column(db.Float, default=0)
    education_allowance = db.Column(db.Float, default=0)
    lta = db.Column(db.Float, default=0)
    personal_allowance = db.Column(db.Float, default=0)

    
    employee_pf = db.Column(db.Float, default=0)
    employer_pf = db.Column(db.Float, default=0)
    medical_insurance = db.Column(db.Float, default=0)


    extra_deductions = db.Column(db.String(500), default="")

    @property
    def gross(self):
        return round(
            (self.basic or 0)
            + (self.hra or 0)
            + (self.education_allowance or 0)
            + (self.lta or 0)
            + (self.personal_allowance or 0),
            2,
        )

    @property
    def extra_deduction_items(self):
        items = []
        if self.extra_deductions:
            for chunk in self.extra_deductions.split(";"):
                if ":" in chunk:
                    n, a = chunk.split(":", 1)
                    try:
                        items.append((n.strip(), float(a)))
                    except ValueError:
                        pass
        return items

    @property
    def total_deductions(self):
        return round(
            (self.employee_pf or 0)
            + (self.employer_pf or 0)
            + (self.medical_insurance or 0)
            + sum(a for _, a in self.extra_deduction_items),
            2,
        )

    @property
    def net(self):
        return round(self.gross - self.total_deductions, 2)
