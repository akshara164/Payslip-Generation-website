from datetime import datetime, date
from . import db


class Employee(db.Model):
    __tablename__ = "employees"

    id = db.Column(db.Integer, primary_key=True)
    employee_id = db.Column(db.String(50), unique=True, nullable=False, index=True)
    name = db.Column(db.String(120), nullable=False)
    designation = db.Column(db.String(120), nullable=False)
    department = db.Column(db.String(120), nullable=False)
    date_of_joining = db.Column(db.Date, nullable=False)
    bank_account = db.Column(db.String(40))
    uan_number = db.Column(db.String(20))
    email = db.Column(db.String(120))
    work_location = db.Column(db.String(120))
    status = db.Column(db.String(20), nullable=False, default="Active")  # Active / Inactive / On Notice
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    salary_versions = db.relationship("SalaryVersion", backref="employee", cascade="all, delete-orphan", lazy=True)
    payslips = db.relationship("Payslip", backref="employee", cascade="all, delete-orphan", lazy=True)
    change_logs = db.relationship("EmployeeChangeLog", backref="employee", cascade="all, delete-orphan", lazy=True)

    def current_salary(self, on_date: date | None = None):
        on_date = on_date or date.today()
        if not self.salary_versions:
            return None
        applicable = [v for v in self.salary_versions if v.effective_date <= on_date]
        # Prefer the version flagged current within applicable
        current_flagged = [v for v in applicable if v.is_current]
        if current_flagged:
            return max(current_flagged, key=lambda v: v.effective_date)
        if applicable:
            return max(applicable, key=lambda v: v.effective_date)
        
        any_current = [v for v in self.salary_versions if v.is_current]
        if any_current:
            return max(any_current, key=lambda v: v.effective_date)
        return min(self.salary_versions, key=lambda v: v.effective_date)


class EmployeeChangeLog(db.Model):
    """Logs changes to designation/department so history isn't overwritten."""
    __tablename__ = "employee_change_logs"

    id = db.Column(db.Integer, primary_key=True)
    employee_pk = db.Column(db.Integer, db.ForeignKey("employees.id"), nullable=False)
    field = db.Column(db.String(40), nullable=False)  # 'designation' or 'department'
    old_value = db.Column(db.String(120))
    new_value = db.Column(db.String(120))
    changed_on = db.Column(db.Date, default=date.today)
