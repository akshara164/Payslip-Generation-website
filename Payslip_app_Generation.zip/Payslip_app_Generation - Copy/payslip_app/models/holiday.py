from datetime import datetime
from . import db


class Holiday(db.Model):
    """Global company holiday calendar. Auto-applied to payroll runs for the matching month."""
    __tablename__ = "holidays"

    id = db.Column(db.Integer, primary_key=True)
    holiday_date = db.Column(db.Date, nullable=False, unique=True)
    name = db.Column(db.String(120), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
