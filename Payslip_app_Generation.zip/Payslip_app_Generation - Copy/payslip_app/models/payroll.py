from datetime import datetime, date
from . import db


class PayrollRun(db.Model):
    __tablename__ = "payroll_runs"

    id = db.Column(db.Integer, primary_key=True)
    month = db.Column(db.Integer, nullable=False)  
    year = db.Column(db.Integer, nullable=False)
    total_working_days = db.Column(db.Integer, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    payslips = db.relationship("Payslip", backref="run", cascade="all, delete-orphan", lazy=True)
    holidays = db.relationship("PublicHoliday", backref="run", cascade="all, delete-orphan", lazy=True)

    __table_args__ = (db.UniqueConstraint("month", "year", name="uq_run_month_year"),)


class PublicHoliday(db.Model):
    __tablename__ = "public_holidays"

    id = db.Column(db.Integer, primary_key=True)
    run_id = db.Column(db.Integer, db.ForeignKey("payroll_runs.id"), nullable=False)
    holiday_date = db.Column(db.Date, nullable=False)
    name = db.Column(db.String(120))


class Payslip(db.Model):
    __tablename__ = "payslips"

    id = db.Column(db.Integer, primary_key=True)
    run_id = db.Column(db.Integer, db.ForeignKey("payroll_runs.id"), nullable=False)
    employee_pk = db.Column(db.Integer, db.ForeignKey("employees.id"), nullable=False)
    salary_version_id = db.Column(db.Integer, db.ForeignKey("salary_versions.id"), nullable=False)

    days_worked = db.Column(db.Float, default=0)
    leaves = db.Column(db.Float, default=0)
    lop_days = db.Column(db.Float, default=0)

    
    basic = db.Column(db.Float, default=0)
    hra = db.Column(db.Float, default=0)
    education_allowance = db.Column(db.Float, default=0)
    lta = db.Column(db.Float, default=0)
    personal_allowance = db.Column(db.Float, default=0)
    employee_pf = db.Column(db.Float, default=0)
    employer_pf = db.Column(db.Float, default=0)
    medical_insurance = db.Column(db.Float, default=0)
    lop_deduction = db.Column(db.Float, default=0)

    gross = db.Column(db.Float, default=0)
    total_deductions = db.Column(db.Float, default=0)
    net = db.Column(db.Float, default=0)

    status = db.Column(db.String(20), default="Draft")  
    pay_date = db.Column(db.Date)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    extra_deductions = db.relationship(
        "PayslipDeduction", backref="payslip", cascade="all, delete-orphan", lazy=True
    )

    salary_version = db.relationship("SalaryVersion")

    __table_args__ = (db.UniqueConstraint("run_id", "employee_pk", name="uq_run_emp"),)


class PayslipDeduction(db.Model):
    __tablename__ = "payslip_deductions"

    id = db.Column(db.Integer, primary_key=True)
    payslip_id = db.Column(db.Integer, db.ForeignKey("payslips.id"), nullable=False)
    name = db.Column(db.String(120), nullable=False)
    amount = db.Column(db.Float, default=0)
